//JSON Array
var text = '{ "employees" : [' +
    '{ "firstName":"John" , "lastName":"Doe" },' +
    '{ "firstName":"Anna" , "lastName":"Smith" },' +
    '{ "firstName":"Peter" , "lastName":"Jones" } ]}';

//JSON Object

var myJSON = {"people":[
    {"name":"John", "job":"Construction"},
    {"name":"Anna", "job":"Teacher"},
    {"name":"Peter", "job":"Astronaut"}
]}


