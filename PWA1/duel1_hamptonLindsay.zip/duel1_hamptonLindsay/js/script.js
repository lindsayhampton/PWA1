/*
 Lindsay Hampton
 May 10, 2015
 PWA 1
 Duel 1
 */

//alert("Testing 1, 2, 3...");

// Players
var p1 = "Sabre Tooth Tiger";
var p2 = "A Bowl of Jello";

// Damage
var oneDamage = 20;
var twoDamage = 15;

var min1 = oneDamage * .5;
var min2 = twoDamage * .5;

// Health
var oneHealth = 100;
var twoHealth = 100;

// Round
var round = 0;

fight();

function fight(){
    alert(p1+": "+oneHealth+" vs. "+p2+": "+twoHealth);
    alert("FIGHT!!!");

    for (var i=0; i < 10; i++){
        var f1 = Math.floor(Math.random()*(oneDamage-min1)+min1);
        var f2 = Math.floor(Math.random()*(twoDamage-min2)+min2);

        oneHealth-=f1;
        twoHealth-=f2;

        console.log(p1+": "+oneHealth+" vs. "+p2+": "+twoHealth);

        var result = winnerCheck();
        console.log(result);
        if (result==="none")
        {
            round++;
            alert(p1+":"+oneHealth+"  *ROUND "+round+" OVER"+"*  "+p2+":"+twoHealth);

        } else {
            alert(result);
            break;
        }
    }

}

function winnerCheck(){
    var result = "none"
    if (oneHealth<1 && twoHealth<1){
        result = "IT'S A DRAW!";
    } else if(oneHealth<1){
        result =p2+" WINS!!!"
    } else if (twoHealth<1){
        result = p1+" WINS!!!"
    }
    return result;
}

