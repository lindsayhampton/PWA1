/*
 Lindsay Hampton
 Date
 Section 00
 Assignment
 */

alert("Testing 1, 2, 3...");
