/*
 Lindsay Hampton
 May 10, 2015
 PWA 1
 Duel 1
 */

//alert("Testing 1, 2, 3...");

// Array
var player1 = ["Sabre Tooth Tiger", 20, 100];
var player2 = ["A Bowl of Jello", 15, 100];

/* Players
var p1 = "Sabre Tooth Tiger";
var p2 = "A Bowl of Jello";

// Damage
var oneDamage = 20;
var twoDamage = 15;

// Health
var oneHealth = 100;
var twoHealth = 100;

 */

var min1 = player1[1] * .5;
var min2 = player2[1] * .5;


// Round
var round = 0;

fight();

function fight(){
    alert(player1[0]+": "+player1[2]+" vs. "+player2[0]+": "+player2[2]);
    alert("FIGHT!!!");

    for (var i=0; i < 10; i++){
        var f1 = Math.floor(Math.random()*(player1[1]-min1)+min1);
        var f2 = Math.floor(Math.random()*(player2[1]-min2)+min2);

        player1[2]-=f1;
        player2[2]-=f2;

        console.log(player1[0]+": "+player1[2]+" vs. "+player2[0]+": "+player2[2]);

        var result = winnerCheck();
        console.log(result);
        if (result==="none")
        {
            round++;
            alert(player1[0]+":"+player1[2]+"  *ROUND "+round+" OVER"+"*  "+player2[0]+":"+player2[2]);

        } else {
            alert(result);
            break;
        }
    }

}

function winnerCheck(){
    var result = "none"
    if (player1[2]<1 && player2[2]<1){
        result = "IT'S A DRAW!";
    } else if(player1[2]<1){
        result =player2[0]+" WINS!!!"
    } else if (player2[2]<1){
        result = player1[0]+" WINS!!!"
    }
    return result;
}

